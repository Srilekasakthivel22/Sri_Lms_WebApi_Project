﻿using Leave_Management_System.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Leave_Management_System.Repository
{
    public interface ILeaveRepo
    {
        Task<List<EmployeeLeave>> GetAllLeave();

        Task<List<EmployeeLeave>> GetLeaveById(int id);

        Task<List<EmployeeLeave>> GetLeaveByMangId(int Id);

        Task<EmployeeLeave> GetLevByLevMang(int levid, int mangid);

        Task<int> ApplyLeave(EmployeeLeave employeeLeave);

        Task<int> ApproveDeny(int levid, EmployeeLeave employeeLeave);

        Task<int> DeleteLeave(int id);

    }
}
