﻿using Leave_Management_System.Models;
using Leave_Management_System.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Leave_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LeaveController : ControllerBase
    {
        private readonly ILeaveRepo leaveRepo;

        public LeaveController(ILeaveRepo leaveRepo)
        {
            this.leaveRepo = leaveRepo;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllLeave()
        {
            var lev = await leaveRepo.GetAllLeave();
            return Ok(lev);
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetLeaveDetailsById(int id)
        {
            var lev = await leaveRepo.GetLeaveById(id);
            return Ok(lev);
        }

        //[HttpGet("{Levid}")]
        //public async Task<IActionResult> GetLeaveDetailsByLevId(int id)
        //{
        //    var lev = await leaveRepo.GetLeaveByLevId(id);
        //    return Ok(lev);
        //}
        [HttpPost]
        public async Task<IActionResult> ApplyLeave(EmployeeLeave employeeLeave)
        {
            var lev = await leaveRepo.ApplyLeave(new EmployeeLeave { LeaveId = employeeLeave.LeaveId, EmployeeId = employeeLeave.EmployeeId, ManagerId = employeeLeave.ManagerId, StartDate = employeeLeave.StartDate, EndDate = employeeLeave.EndDate, NoOfDays = employeeLeave.NoOfDays, LeaveType = employeeLeave.LeaveType, LeaveReason = employeeLeave.LeaveReason, Status = employeeLeave.Status, ManagerComment = employeeLeave.ManagerComment });
            return Ok(lev);
        }




        [HttpDelete]
        public async Task<IActionResult> DeleteLeave(int id)
        {
            var lev = await leaveRepo.DeleteLeave(id);
            return Ok(lev);
        }

        [HttpPut]
        public async Task<IActionResult> ApproveOrDeny(int levid, EmployeeLeave employeeLeave)
        {
            var lev = await leaveRepo.ApproveDeny(levid, employeeLeave);
            return Ok(lev);
        }
        [HttpGet("/")]
        public async Task<IActionResult> GetLeaveByMgId(int id)
        {

            var lev = await leaveRepo.GetLeaveByMangId(id);
            return Ok(lev);
        }

        [HttpGet("{mangid}/{levid}")]
        public async Task<IActionResult> GetLevBylevmang(int mangid,int levid)
        {
            var lev = await leaveRepo.GetLevByLevMang(mangid, levid);
            return Ok(lev);
        }

    }
}
